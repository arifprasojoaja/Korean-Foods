package com.example.koreanfoods

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream
import java.lang.Exception

class Produk : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk)
        val rv_produk: RecyclerView =findViewById(R.id.rv_produk)
        val iv_kembali:ImageView=findViewById(R.id.iv_kembali)
        val id_produk:MutableList<String> = mutableListOf()
        val nama_produk: MutableList<String> = mutableListOf()
        val harga_produk: MutableList<String> = mutableListOf()
        val foto_produk: MutableList<Bitmap> = mutableListOf()
        val db : SQLiteDatabase = openOrCreateDatabase("db_nopan", MODE_PRIVATE, null)
        val gali_produk = db.rawQuery("SELECT * FROM produk", null)
        while (gali_produk.moveToNext())
        {
            try {
                val bis = ByteArrayInputStream(gali_produk.getBlob(3))
                val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
                foto_produk.add(gambarbitmap)

            }catch (e: Exception){
                val gambarbitmap= BitmapFactory.decodeResource(this.resources,R.drawable.upload)
                foto_produk.add(gambarbitmap)
            }
            id_produk.add(gali_produk.getString(0))
            nama_produk.add(gali_produk.getString(1))
            harga_produk.add(gali_produk.getString(2))
        }
        iv_kembali.setOnClickListener {
            val pindah:Intent=Intent(this,Dashboard::class.java)
            startActivity(pindah)
        }

        val adapter = Produk_item(this,id_produk, nama_produk, harga_produk, foto_produk)
        rv_produk.adapter = adapter
        rv_produk.layoutManager = GridLayoutManager(this, 1)
    }
}
package com.example.koreanfoods

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard)
        val btn_produk:Button=findViewById(R.id.btn_produk)
        val btn_akun:Button=findViewById(R.id.btn_akun)
        btn_produk.setOnClickListener {
            val pindahproduk = Intent(this, Produk::class.java)
            startActivity(pindahproduk)
        }
        btn_akun.setOnClickListener {
            val pindahakun = Intent(this,Akun::class.java)
            startActivity(pindahakun)
        }
    }
}
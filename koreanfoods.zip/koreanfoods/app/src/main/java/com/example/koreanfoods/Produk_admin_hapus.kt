package com.example.koreanfoods

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Produk_admin_hapus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk_admin_hapus)
        val id_produk_terpilih:String = intent.getStringExtra("id_produk_terpilih").toString()
        val db : SQLiteDatabase = openOrCreateDatabase("db_nopan", MODE_PRIVATE, null)
        val query = db.rawQuery("DELETE FROM produk WHERE id_produk='$id_produk_terpilih'", null)
        query.moveToNext()
        val pindah: Intent = Intent(this, Produk_admin::class.java)
        startActivity(pindah)
    }
}
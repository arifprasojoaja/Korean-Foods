package com.example.koreanfoods

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import java.io.ByteArrayOutputStream

class Produk_admin_tambah : AppCompatActivity() {
    var iv_upload: ImageView? = null
    var urlgambar: Uri? = null
    var bitmapgambar : Bitmap? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk_admin_tambah)
        val edt_nama_produk: EditText = findViewById(R.id.edt_nama_produk)
        val edt_harga_produk: EditText = findViewById(R.id.edt_harga_produk)
        val btn_simpan: Button = findViewById(R.id.btn_simpan)
        iv_upload = findViewById(R.id.iv_upload)
        iv_upload?.setOnClickListener {
            val bukagaleri: Intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            pilih_gambar.launch(bukagaleri)
        }
        btn_simpan.setOnClickListener {
            val nama_produk:String = edt_nama_produk.text.toString()
            val harga_produk:String = edt_harga_produk.text.toString()
            val bos = ByteArrayOutputStream()
            bitmapgambar?.compress(Bitmap.CompressFormat.JPEG, 100, bos)
            val bytearraygambar = bos.toByteArray()
            val db: SQLiteDatabase = openOrCreateDatabase("db_nopan", MODE_PRIVATE,null)
            val sql = "INSERT INTO produk (nama_produk,harga_produk,foto_produk) VALUES(?,?,?)"
            val statement = db.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1, nama_produk)
            statement.bindString(2, harga_produk)
            statement.bindBlob(3, bytearraygambar)
            statement.executeInsert()
            val pindah: Intent = Intent(this, Produk_admin::class.java)
            startActivity(pindah)

        }
    }
    val pilih_gambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
        val gambardiperoleh = it.data
        if (gambardiperoleh !=null){
            urlgambar = gambardiperoleh.data
            bitmapgambar = MediaStore.Images.Media.getBitmap(contentResolver, urlgambar)
            iv_upload?.setImageBitmap(bitmapgambar)
        }
    }
}
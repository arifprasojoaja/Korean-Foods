package com.example.koreanfoods

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Dashboard_admin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard_admin)
        val btn_produk: Button =findViewById(R.id.btn_produk)
        val btn_akun: Button =findViewById(R.id.btn_akun)
        val btn_pesanan: Button =findViewById(R.id.btn_pesanan)
        btn_produk.setOnClickListener {
            val pindahproduk = Intent(this, Produk_admin::class.java)
            startActivity(pindahproduk)
        }
        btn_akun.setOnClickListener {
            val pindahakun = Intent(this,Akun_admin::class.java)
            startActivity(pindahakun)
        }
        btn_pesanan.setOnClickListener {
            val pindahpesanan = Intent(this,Pesanan::class.java)
            startActivity(pindahpesanan)
        }
    }
}
package com.example.koreanfoods

import android.content.Intent
import android.content.SharedPreferences
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Akun_admin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.akun_admin)
        val txt_nama: TextView =findViewById(R.id.txt_nama)
        val txt_email: TextView =findViewById(R.id.txt_email)
        val txt_password: TextView =findViewById(R.id.txt_password)
        val db: SQLiteDatabase = openOrCreateDatabase("db_nopan", MODE_PRIVATE, null)
        val tiket: SharedPreferences =getSharedPreferences("admin", MODE_PRIVATE)
        val email_admin:String?=tiket.getString("email_admin",null)
        val password:String?=tiket.getString("password",null)
        val cursor: Cursor = db.rawQuery("SELECT nama_admin FROM admin WHERE email_admin = ? AND password = ?", arrayOf(email_admin, password))
        if (cursor.moveToFirst()) {
            val namaadminIndex: Int = cursor.getColumnIndex("nama_admin")
            val namaadmin: String = cursor.getString(namaadminIndex)

            txt_nama.text = "$namaadmin"
        }
        txt_email.text="Email : "+email_admin
        txt_password.text="Password : "+password
        val txt_logout: TextView =findViewById(R.id.txt_logout)
        txt_logout.setOnClickListener {
            val edit_tiket = tiket.edit()
            edit_tiket.clear()
            edit_tiket.commit()
            val pindah: Intent = Intent(this,Login::class.java)
            startActivity(pindah)
        }
    }
}
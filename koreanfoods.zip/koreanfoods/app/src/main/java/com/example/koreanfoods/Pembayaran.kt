package com.example.koreanfoods

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import java.io.ByteArrayOutputStream

class Pembayaran : AppCompatActivity() {
    var bitmapgambar : Bitmap? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pembayaran)
        val txt_nama_produk: TextView =findViewById(R.id.txt_nama_produk)
        val txt_harga_produk: TextView =findViewById(R.id.txt_harga_produk)
        val nama_produk: String? = intent.getStringExtra("nama_produk")
        val harga_produk: String? = intent.getStringExtra("harga_produk")
        if (nama_produk != null && harga_produk != null) {

            txt_nama_produk.text = nama_produk
            txt_harga_produk.text = harga_produk
        }
        val edt_jumlahproduk: TextView =findViewById(R.id.edt_jumlah)
        val btn_beli:Button=findViewById(R.id.btn_beli)
        btn_beli.setOnClickListener {
            val jumlah_produk:String=edt_jumlahproduk.text.toString()
            val nama_produk:String = txt_nama_produk.text.toString()
            val harga_produk:String = txt_harga_produk.text.toString()
            val db: SQLiteDatabase = openOrCreateDatabase("db_nopan", MODE_PRIVATE,null)
            val sql = "INSERT INTO pesanan (jumlah,nama_produk,harga_produk) VALUES(?,?,?)"
            val statement = db.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1, jumlah_produk)
            statement.bindString(2, nama_produk)
            statement.bindString(3, harga_produk)
            statement.executeInsert()
            val pindah: Intent = Intent(this, Pesanan_berhasil::class.java)
            startActivity(pindah)
        }
    }
}
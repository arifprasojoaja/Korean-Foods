package com.example.koreanfoods

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Produk_item(val ini: Context, val id_produk:MutableList<String>, val nama:MutableList<String>, val harga_produk:MutableList<String>, val foto_produk:MutableList<Bitmap>) : RecyclerView.Adapter<Produk_item.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.produk_item,parent,false)
        return ViewHolder(view)
    }
    class  ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val txt_nama_produk: TextView = itemView.findViewById(R.id.txt_nama_produk)
        val txt_harga_produk: TextView = itemView.findViewById(R.id.txt_harga_produk)
        val iv_foto_produk: ImageView = itemView.findViewById(R.id.iv_foto_produk)
        val btn_beli:Button = ItemView.findViewById(R.id.btn_beli)
    }
    override fun getItemCount(): Int {
        return nama.size
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txt_nama_produk.text = nama.get(position)
        holder.txt_harga_produk.text = harga_produk.get(position)

        holder.iv_foto_produk.setImageBitmap(foto_produk.get(position))
        holder.btn_beli.setOnClickListener {
            val pindah:Intent=Intent(ini, Pembayaran::class.java)
            pindah.putExtra("nama_produk", nama[position])
            pindah.putExtra("harga_produk", harga_produk[position])
            ini.startActivity(pindah)
        }

    }
}
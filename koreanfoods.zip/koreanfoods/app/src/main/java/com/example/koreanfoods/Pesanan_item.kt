package com.example.koreanfoods

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Pesanan_item(val ini: Context, val nama:MutableList<String>, val harga_produk:MutableList<String>,val jumlah:MutableList<String>) : RecyclerView.Adapter<Pesanan_item.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.pesanan_item,parent,false)
        return ViewHolder(view)
    }
    class  ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val txt_nama_produk: TextView = itemView.findViewById(R.id.txt_nama_produk)
        val jumlah: TextView = itemView.findViewById(R.id.txt_jumlah)
    }
    override fun getItemCount(): Int {
        return nama.size
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txt_nama_produk.text = nama.get(position)
        holder.jumlah.text=jumlah.get(position)
    }
}
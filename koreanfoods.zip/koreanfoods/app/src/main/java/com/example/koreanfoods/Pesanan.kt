package com.example.koreanfoods

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream
import java.lang.Exception

class Pesanan : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pesanan)
        val rv_pesanan: RecyclerView =findViewById(R.id.rv_pesanan)
        val nama_produk: MutableList<String> = mutableListOf()
        val harga_produk: MutableList<String> = mutableListOf()
        val jumlah: MutableList<String> = mutableListOf()
        val db : SQLiteDatabase = openOrCreateDatabase("db_nopan", MODE_PRIVATE, null)
        val gali_pesanan = db.rawQuery("SELECT * FROM pesanan", null)
        while (gali_pesanan.moveToNext())
        {

            jumlah.add(gali_pesanan.getString(1))
            nama_produk.add(gali_pesanan.getString(2))
            harga_produk.add(gali_pesanan.getString(3))

        }
        val adapter = Pesanan_item(this,nama_produk, harga_produk, jumlah)
        rv_pesanan.adapter = adapter
        rv_pesanan.layoutManager = GridLayoutManager(this, 1)
        val iv_kembali:ImageView=findViewById(R.id.iv_kembali)
        iv_kembali.setOnClickListener {
            val pindah:Intent=Intent(this,Dashboard_admin::class.java)
            startActivity(pindah)
        }
    }
}
package com.example.koreanfoods

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.lang.Exception

class Produk_admin_edit : AppCompatActivity() {
    var urlgambar: Uri?=null
    var bitmapgambar:Bitmap?=null
    var iv_upload: ImageView?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk_admin_edit)
        val id_produk_terpilih:String = intent.getStringExtra("id_produk_terpilih").toString()
        val db: SQLiteDatabase = openOrCreateDatabase("db_nopan", MODE_PRIVATE, null)
        val ambil = db.rawQuery("SELECT * FROM produk WHERE id_produk = '$id_produk_terpilih'",null)
        if (ambil.moveToNext())
        {
            val isi_nama:String = ambil.getString(1)
            val isi_harga:String = ambil.getString(2)
            val isi_foto:ByteArray=ambil.getBlob(3)
            val edt_nama_produk: EditText =findViewById(R.id.edt_nama_produk)
            val edt_harga_produk: EditText =findViewById(R.id.edt_harga_produk)
            val btn_simpan: Button = findViewById(R.id.btn_simpan)
            iv_upload = findViewById(R.id.iv_upload)
            edt_nama_produk.setText(isi_nama)
            edt_harga_produk.setText(isi_harga)
            try {
                val bis = ByteArrayInputStream(isi_foto)
                val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
                iv_upload?.setImageBitmap(gambarbitmap)

            }catch (e: Exception){
                val gambarbitmap= BitmapFactory.decodeResource(this.resources,R.drawable.upload)
                iv_upload?.setImageBitmap(gambarbitmap)
            }
            iv_upload?.setOnClickListener {
                val bukagaleri: Intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
                pilih_gambar.launch(bukagaleri)
            }

            btn_simpan.setOnClickListener {
                val nama_baru:String = edt_nama_produk.text.toString()
                val harga_baru:String = edt_harga_produk.text.toString()
                val bos = ByteArrayOutputStream()
                bitmapgambar?.compress(Bitmap.CompressFormat.JPEG, 100,bos)
                val bytearraygambar = bos.toByteArray()
                val sql = "UPDATE produk SET nama_produk=?, harga_produk=?,foto_produk=? WHERE id_produk='$id_produk_terpilih'"
                val statement = db.compileStatement(sql)
                statement.clearBindings()
                statement.bindString(1, nama_baru)
                statement.bindString(2, harga_baru)
                statement.bindBlob(3, bytearraygambar)
                statement.executeUpdateDelete()
                val pindah: Intent = Intent(this, Produk_admin::class.java)
                startActivity(pindah)

            }
        }




    }
    val pilih_gambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
        if (it.resultCode== Activity.RESULT_OK){
            val gambardiperoleh = it.data
            if(gambardiperoleh!=null){
                urlgambar =gambardiperoleh.data
                bitmapgambar = MediaStore.Images.Media.getBitmap(contentResolver,urlgambar)
                iv_upload?.setImageBitmap(bitmapgambar)

            }
        }
    }
}